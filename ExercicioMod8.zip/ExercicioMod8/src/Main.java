public class Main {
    public static void main(String[] args) {
        Media m = new Media();

        m.nota1 = 8f;
        System.out.println("A primeira nota é: "+ m.nota1);
        m.nota2 = 7f;
        System.out.println("A Segunda nota é: "+m.nota2);
        m.nota3 = 5f;
        System.out.println("A terceira nota é: "+m.nota3);
        m.nota4 = 7f;
        System.out.println("A quarta nota é "+m.nota4);

        m.soma = m.nota1 + m.nota2 + m.nota3 + m.nota4;
        System.out.println(m.soma);

        m.mediaNota = m.soma / 4f;
        System.out.println("A média das notas é: " + " "+ m.mediaNota);




    }
}