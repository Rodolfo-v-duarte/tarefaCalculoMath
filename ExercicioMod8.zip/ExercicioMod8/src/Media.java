public class Media {
    float nota1;
    float nota2;
    float nota4;
    float nota3;
    float soma;
    float mediaNota;

}
